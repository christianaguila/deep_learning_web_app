(function ($) {
    'use strict';

$(window).load(function() {
    $('#preloader-wrapper').fadeOut('slow');
});
    // Gallery Popup
    $('.image-popup').magnificPopup({type:'image'});

})(jQuery);




